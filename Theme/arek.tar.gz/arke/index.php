<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 *
 * @link       https://codex.wordpress.org/Template_Hierarchy
 *
 * @package    Arke
 * @copyright  Copyright (c) 2018, Danny Cooper
 * @license    http://opensource.org/licenses/gpl-2.0.php GNU Public License
 */

get_template_part( 'header' );

				if ( have_posts() ) :

					while ( have_posts() ) :

						the_post();

						get_template_part( 'content' );

						// If comments are open or we have at least one comment, load up the comment template.
						if ( comments_open() || get_comments_number() ) :
							comments_template();
						endif;

					endwhile;

				else :

					get_template_part( 'content', 'none' );

				endif;
				?>

				</div><!-- .content-area -->
		</div><!-- .site-content -->
		<?php if ( get_page_by_path( 'archives' ) ) : ?>
		
		</div>
			
		<?php else : ?>
			<?php arke_the_posts_navigation(); ?>
		<?php endif; ?>
		<?php wp_footer(); ?>
		
		<!--Footer-->
		<div class="footer" id="footer">
        <p>
        Make everything <span class="author"
              itemprop="copyrightHolder">Simple</span>.
        <label class="el-switch el-switch-green el-switch-sm"
               style="vertical-align: sub;">
            <input type="checkbox"
                   name="switch"
                   id="update_style">
            <span class="el-switch-style"></span>
        </label>
    </p>
</div>
		
		<!--Live2D-->
		<script src="https://cdn.jsdelivr.net/gh/inGeoscience/Live2Dgithub/live2dw/lib/L2Dwidget.min.js"></script>
        <script>
        if(/Android|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent)) {
        L2Dwidget.init({ 
		"model": { "jsonPath":"https://cdn.jsdelivr.net/gh/inGeoscience/Live2DModels/model/dollsfrontline/kp31_310/destroy/model.json", "scale": 1, "hHeadPos":0.5, "vHeadPos":0.618 },
		"display": { "position": "right", "width": 75, "height": 150, "hOffset": 0, "vOffset": -30 }, 
		"mobile": { "show": true, "scale": 0.5 },
		"react": { "opacityDefault": 1, "opacityOnHover": 0.2 } 
		});
        } 
        else {
        L2Dwidget.init({ 
		"model": { "jsonPath":"https://cdn.jsdelivr.net/gh/inGeoscience/Live2DModels/model/dollsfrontline/kp31_310/destroy/model.json", "scale": 1, "hHeadPos":0.5, "vHeadPos":0.618 },
		"display": { "position": "right", "width": 150, "height": 300, "hOffset": 0, "vOffset": -70 }, 
		"mobile": { "show": true, "scale": 0.5 },
		"react": { "opacityDefault": 1, "opacityOnHover": 0.2 } 
		});
        }
        </script>
        
	</body>
</html>
