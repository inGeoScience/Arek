<?php
/**
 * Template Name: Archive Template
 *
 * @package    Arek
 * @copyright  Copyright (c) 2020, Cake Sunny
 * @license    https://index.city Public License
 */

get_template_part( 'header' );
?>
				<header>
					<h1 class="archives__heading"><?php single_post_title(); ?></h1>
				</header>

				<?php

				$args = array(
					'post_type'      => 'post',
					'post_status'    => 'publish',
					'posts_per_page' => -1,
				);

				$arke_posts = new WP_Query( $args );

				if ( $arke_posts->have_posts() ) :

					echo '<ul class="archives__list">';

					while ( $arke_posts->have_posts() ) :
						$arke_posts->the_post();

						echo '<li><a href="' . esc_url( get_the_permalink() ) . '">' . get_the_title() . '</a><span>' . esc_attr( get_the_time( 'y年m月d日' ) ) . '</span></li>';

					endwhile;

					echo '</ul>';

					wp_reset_postdata();

				else :
						echo '<p>' . esc_html__( 'Sorry, no posts matched your criteria.', 'arke' ) . '</p>';
				endif;
				?>


				</div><!-- .content-area -->
		</div><!-- .site-content -->
		<footer class="site-footer">
				<?php
				// translators: %1$s: theme name.
				// translators: %2$s: theme author.
				printf( esc_html__( 'Theme: %1$s by %2$s.', 'arke' ), '<a href="https://olympusthemes.com/themes/arke/">Arke</a>', 'Danny Cooper' );
				?>
		</footer><!-- .site-footer -->
		
				<div class="footer" id="footer">
        <p>
        Make everything <span class="author"
              itemprop="copyrightHolder">Simple</span>.
        <label class="el-switch el-switch-green el-switch-sm"
               style="vertical-align: sub;">
            <input type="checkbox"
                   name="switch"
                   id="update_style">
            <span class="el-switch-style"></span>
        </label>
    </p>
</div>
		
		<!--Live2D-->
		<script src="https://cdn.jsdelivr.net/gh/inGeoscience/Live2Dgithub/live2dw/lib/L2Dwidget.min.js"></script>
        <script>
        if(/Android|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent)) {
        L2Dwidget.init({ 
		"model": { "jsonPath":"https://cdn.jsdelivr.net/gh/inGeoscience/Live2DModels/model/dollsfrontline/kp31_310/destroy/model.json", "scale": 1, "hHeadPos":0.5, "vHeadPos":0.618 },
		"display": { "position": "right", "width": 75, "height": 150, "hOffset": 0, "vOffset": -30 }, 
		"mobile": { "show": true, "scale": 0.5 },
		"react": { "opacityDefault": 1, "opacityOnHover": 0.2 } 
		});
        } 
        else {
        L2Dwidget.init({ 
		"model": { "jsonPath":"https://cdn.jsdelivr.net/gh/inGeoscience/Live2DModels/model/dollsfrontline/kp31_310/destroy/model.json", "scale": 1, "hHeadPos":0.5, "vHeadPos":0.618 },
		"display": { "position": "right", "width": 150, "height": 300, "hOffset": 0, "vOffset": -70 }, 
		"mobile": { "show": true, "scale": 0.5 },
		"react": { "opacityDefault": 1, "opacityOnHover": 0.2 } 
		});
        }
        </script>
        
		<?php wp_footer(); ?>
	</body>
</html>
